Imperatore — Kadence Theme (Block)

Installazione:
- WordPress → Aspetto → Temi → Aggiungi nuovo → Carica tema → seleziona lo ZIP → Attiva.

Note Kadence:
- Il layout è pensato per essere modificato con Kadence Blocks.
- Pattern incluso: "Homepage — Imperatore (Kadence-friendly)" (in Pattern → Imperatore).
- Per il logo in header usa "Site Logo" dal Site Editor (così non sovrascriviamo i tuoi loghi).


Aggiornamento 1.3:
- Rimossi template dedicati (resta solo index.html)
- Riabilitate opzioni di personalizzazione (colori, tipografia, spacing)
- Aggiunti font Inter + Poppins e palette colori dal mock.
